package com.nmustakim.weather_forecast;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
