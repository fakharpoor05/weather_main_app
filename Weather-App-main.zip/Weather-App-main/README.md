# weather

A very simple app made with openweathermap API
